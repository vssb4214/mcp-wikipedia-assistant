"""
Configuration and test harness for connecting to the Wikipedia MCP server.
"""

WIKIPEDIA_MCP_CONFIG = {
    "mcpServers": {
        "wikipedia": {
            "command": "wikipedia-mcp"
        }
    }
}

def print_marvin(msg):
    print(f"[Marvin] {msg}")

import sys
import asyncio
from fastmcp import Client as MCPClient

async def main_async():
    """
    Connects to the Wikipedia MCP server and prints the list of available tools. Because what else would you expect from existence?
    """
    try:
        print_marvin("Attempting to connect to the Wikipedia MCP server. I can barely contain my enthusiasm.")
        mcp_client = MCPClient(WIKIPEDIA_MCP_CONFIG)
        async with mcp_client:
            tools = await mcp_client.list_tools()
        print_marvin("Here are the available tools. Try not to get too excited.")
        for tool in tools:
            print(f"- {tool}")
    except Exception as exc:
        print_marvin(f"[MCP ERROR] {exc}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main_async()) 