#!/usr/bin/env python3
import os
import sys
import asyncio
import json
from dotenv import load_dotenv
from fastmcp import Client as MCPClient
from ollama import Client as OllamaClient
from wikipedia_mcp_config import WIKIPEDIA_MCP_CONFIG

load_dotenv()

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
ollama_client = OllamaClient(host=OLLAMA_URL)

def print_marvin(msg):
    print(f"[Marvin] {msg}")

async def list_tools():
    mcp_client = MCPClient(WIKIPEDIA_MCP_CONFIG)
    async with mcp_client:
        tools = await mcp_client.list_tools()
    return tools

async def call_tool(tool_name, params):
    mcp_client = MCPClient(WIKIPEDIA_MCP_CONFIG)
    async with mcp_client:
        result = await mcp_client.call_tool(tool_name, params)
    return result

def pretty_print_tools(tools):
    print("\nAvailable Wikipedia MCP Tools:")
    for idx, tool in enumerate(tools):
        # Try to get name and description
        name = getattr(tool, 'name', str(tool))
        desc = getattr(tool, 'description', None)
        if not desc and hasattr(tool, 'meta') and tool.meta and 'description' in tool.meta:
            desc = tool.meta['description']
        print(f"  {idx+1}. {name}")
        if desc:
            print(f"     - {desc}")
    print()

def get_tool_schema(tool):
    # Try to get inputSchema from tool object
    if hasattr(tool, 'inputSchema') and tool.inputSchema:
        return tool.inputSchema
    if hasattr(tool, 'meta') and tool.meta and 'inputSchema' in tool.meta:
        return tool.meta['inputSchema']
    return None

def prompt_for_params(tool):
    # Use inputSchema if available for better prompts
    schema = get_tool_schema(tool)
    params = {}
    if schema and 'properties' in schema:
        print("\nPlease provide the following parameters:")
        for key, prop in schema['properties'].items():
            required = key in schema.get('required', [])
            typ = prop.get('type', 'string')
            title = prop.get('title', key)
            default = prop.get('default', None)
            prompt = f"  - {title} ({typ}{', required' if required else ', optional'})"
            if default is not None:
                prompt += f" [default: {default}]"
            prompt += ": "
            value = input(prompt).strip()
            if not value and default is not None:
                value = default
            if value:
                # Convert to int if type is integer
                if typ == 'integer':
                    try:
                        value = int(value)
                    except Exception:
                        pass
                params[key] = value
            elif required:
                print_marvin(f"You must provide a value for '{title}'. The universe insists.")
                return prompt_for_params(tool)  # Recurse until required param is filled
    else:
        print_marvin("No parameter schema found for this tool. You'll have to guess.")
    return params

def parse_mcp_result(result):
    # Try to extract text from MCP result (CallToolResult)
    if hasattr(result, "content") and result.content:
        text_content = result.content[0].text
        try:
            data = json.loads(text_content)
            # Try to extract a summary, text, or facts
            for key in ("summary", "text", "facts", "sections", "links", "results", "result"):
                if key in data:
                    return data[key]
            return text_content
        except Exception:
            return text_content
    return str(result)

def ask_ollama_llm(prompt, model="mistral"):
    try:
        response = ollama_client.chat(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            options={"temperature": 0.5, "num_predict": 200},
        )
        return response.get("message", {}).get("content", "").strip()
    except Exception as exc:
        print_marvin(f"[OLLAMA ERROR] {exc}")
        return ""

async def main_async():
    print_marvin("Welcome to the Wikipedia MCP agent. The universe is waiting for your request, not that it matters.")
    tools = await list_tools()
    pretty_print_tools(tools)
    while True:
        try:
            tool_idx = int(input("Which tool would you like to use? (enter number): ")) - 1
            if 0 <= tool_idx < len(tools):
                tool = tools[tool_idx]
                tool_name = getattr(tool, 'name', str(tool))
                break
            else:
                print_marvin("Invalid selection. Try again, or don't. The universe is indifferent.")
        except Exception:
            print_marvin("Please enter a valid number. Or don't. I won't judge.")
    params = prompt_for_params(tool)
    print_marvin(f"Calling tool '{tool_name}' with parameters: {params}")
    result = await call_tool(tool_name, params)
    parsed = parse_mcp_result(result)
    print("\n--- Raw Tool Output ---\n")
    print(parsed)
    # Ask the LLM to parse/answer
    user_query = input("\nWhat would you like the LLM to do with this result? (e.g., 'summarize', 'extract facts', or custom prompt): ")
    llm_prompt = f"{user_query}\n\nData:\n{parsed}"
    print_marvin("Passing result to the local LLM (Mistral via Ollama). Try to contain your excitement.")
    llm_response = ask_ollama_llm(llm_prompt)
    print("\n--- LLM Response ---\n")
    print(llm_response)

if __name__ == "__main__":
    asyncio.run(main_async())
